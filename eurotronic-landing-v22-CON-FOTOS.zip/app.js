const WHATSAPP = '5491135962790';

function openWhatsApp({ name, surname, email, country, province, interest }) {
  const fullName = `${name.trim()} ${surname.trim()}`.trim();
  const location = `${province.trim()}, ${country.trim()}`;
  const text = `Hola Eurotronic, quiero inscribirme a tu capacitación de Reparación de inyectores Common Rail.\n\n*${interest.trim()}.*\n\nMi nombre es ${fullName}, soy de ${location}.\nMail: ${email.trim()}`;
  window.location.href = `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`;
}

const registrationForm = document.querySelector('#registration-form');
if (registrationForm) {
  registrationForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(registrationForm).entries());
    openWhatsApp(data);
  });
}

const galleryTrack = document.querySelector('[data-gallery-track]');
const galleryPrev = document.querySelector('[data-gallery-prev]');
const galleryNext = document.querySelector('[data-gallery-next]');

function moveGallery(direction) {
  if (!galleryTrack) return;
  const slide = galleryTrack.querySelector('.gallery-slide');
  if (!slide) return;
  const gap = parseFloat(getComputedStyle(galleryTrack).gap) || 0;
  galleryTrack.scrollBy({ left: direction * (slide.getBoundingClientRect().width + gap), behavior: 'smooth' });
}

if (galleryPrev && galleryNext) {
  galleryPrev.addEventListener('click', () => moveGallery(-1));
  galleryNext.addEventListener('click', () => moveGallery(1));
}

function initAutoCarousel(trackSelector, interval = 4200) {
  const track = document.querySelector(trackSelector);
  if (!track) return;

  const slides = Array.from(track.children);
  if (slides.length < 2 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  let timer = null;
  let paused = false;
  let currentIndex = 0;
  let isVisible = false;

  const nearestIndex = () => {
    const left = track.scrollLeft;
    let best = 0;
    let bestDistance = Infinity;
    slides.forEach((slide, index) => {
      const distance = Math.abs(slide.offsetLeft - left);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = index;
      }
    });
    return best;
  };

  const advance = () => {
    if (paused || !isVisible) return;
    currentIndex = (nearestIndex() + 1) % slides.length;
    // Scroll only the horizontal carousel itself; never move the document/page.
    track.scrollTo({ left: slides[currentIndex].offsetLeft, top: 0, behavior: 'smooth' });
  };

  const start = () => {
    clearInterval(timer);
    timer = setInterval(advance, interval);
  };

  const pause = () => {
    paused = true;
    clearInterval(timer);
  };

  const resume = () => {
    paused = false;
    currentIndex = nearestIndex();
    start();
  };

  track.addEventListener('mouseenter', pause);
  track.addEventListener('mouseleave', resume);
  track.addEventListener('focusin', pause);
  track.addEventListener('focusout', resume);
  track.addEventListener('touchstart', pause, { passive: true });
  track.addEventListener('touchend', () => setTimeout(resume, 1800), { passive: true });
  track.addEventListener('wheel', pause, { passive: true });

  const observer = new IntersectionObserver((entries) => {
    isVisible = entries[0].isIntersecting;
    if (isVisible && !paused) start();
    else clearInterval(timer);
  }, { threshold: 0.25 });
  observer.observe(track);
}

initAutoCarousel('[data-gallery-track]');
initAutoCarousel('[data-reviews-track]', 4800);
